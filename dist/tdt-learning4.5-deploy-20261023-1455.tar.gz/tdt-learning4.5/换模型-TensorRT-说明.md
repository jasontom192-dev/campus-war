# 换模型记录：Infantry-v8n ONNX + TensorRT

**状态（2026-09-27）**：✅ **已打通并跑通验收**。TensorRT 二进制补齐 → 建出 engine →
`auto_aim` 在测试视频上跑完 1546 帧不崩、平均 2.3 ms/帧。第 5 节是对着结果逐条核过的清单。

原样保留的旧记录（改动内容、网络实测、备选方案）在第 1、2、4、7 节。

---

## 1. 做了什么

把 4.4 的检测链路整个换掉：

| | 改之前（4.2 原样） | 改之后 |
| --- | --- | --- |
| 模型 | `yolov8.xml`（OpenVINO IR，416×416） | `Infantry-v8n-fp16-20260726-D1.8w-B16.onnx` → TensorRT engine（480×640） |
| 后端 | OpenVINO | **TensorRT / CUDA** |
| 装甲板数字 | 另跑 `tiny_resnet.onnx` 分类 | **不需要**，新模型端到端直接给 |
| 相机内参 | 自己录屏标定的 1920 系 | **规则手册 7.1 标称值**（960×720） |

新模型 `Infantry-v8n` 的输入输出（实测，与 engine 里的 binding 一致）：

```
in  images  [1, 3, 480, 640] f32     RGB、0~1、NCHW
out output0 [1, 21, 6300]   f32
     [0:4]   颜色 4 类：蓝 红 白 紫
     [4:13]  兵种 9 类：哨兵 英雄 工程 3号步兵 4号步兵 5号步兵 前哨站 基地(底部) 基地(顶部)
     [13:21] 4 个关键点 (x, y)，顺序：左上 左下 右下 右上
```

因为模型自带颜色和兵种，旧版的 `tiny_resnet` 分类器、`classify()`、`ok_name/ok_type`
两级过滤全部删掉了。`detector.cpp` 从 204 行缩到 ~100 行。

## 2. 改了哪些文件

| 文件 | 改动 |
| --- | --- |
| `src/detector.hpp/.cpp` | **重写**。内部改用 NNdeployment 的 `ArmorModel`；`NetArmorResult → Armor` 的映射（关键点顺序 `[0,3,2,1]` 重排、颜色/兵种/大小板） |
| `config.yaml` | 顶层放**规则手册 7.1 标称内参**（fx=fy=1159.420、cx=480、cy=360、无畸变）；新增 `video:` 块放离线测试视频及其真值内参；删掉 `yolo_model`/`classifier_model`/`nms_threshold`/`min_confidence` 等失效项 |
| `src/main.cpp` | 读 `video:` 块；新增 `save_frames_dir`/`save_every_n`（存标注帧复核）、`show_window`；打印每帧耗时与检出摘要 |
| `CMakeLists.txt` | 去掉 OpenVINO，C++17→**C++20**，`add_subdirectory(third_party/NNdeployment)`，自动探测 TensorRT 与 cudart 路径并写进 RPATH |
| `third_party/NNdeployment/` | **新搬进来的**推理库（来自 26_NNDeployment 仓库）。只改了它的 CMakeLists 两处：CUDA toolkit 找不到时用外部传入的 cudart；不再写死 `/usr/src/tensorrt` 之类路径 |
| `tools/build_engine.sh` | **新增**。用 `trtexec` 把 ONNX 编成 engine（原来那个 `build_engine.py` 要 pip 的 tensorrt 包，本机装不了，脚本保留但走不通） |

没动的：`solver / tracker / target / aimer / ekf / visualizer / trajectory` —— 下游一行没改，
因为 `Detector::detect()` 的返回类型（`std::list<Armor>`）保持不变。

## 3. TensorRT 怎么装上的（2026-09-26 下载 + 2026-09-27 补完）

NVIDIA 中国 CDN 的整包 tarball（7.05 GiB）：

```
https://developer.download.nvidia.cn/compute/machine-learning/tensorrt/10.16.1/tars/TensorRT-10.16.1.11.Linux.x86_64-gnu.cuda-13.2.tar.gz
```

**现在包是完整下完的**，留在 `~/TensorRT_dl/trt.tar.gz`（7.1 GB，没删 —— 它是这些二进制
唯一的本地副本，以后要补哪个 lib 直接 `tar -xzf ... TensorRT-10.16.1.11/lib/<名字>` 就行）。

落到 `~/TensorRT/` 的结构：

```
include/                                          头文件（NvInfer.h / NvOnnxParser.h …）
bin/trtexec                                       建 engine 全靠它
lib/libnvinfer.so.10.16.1                632 MB   推理主库
lib/libnvinfer_builder_resource_ptx.so.10.16.1    建 engine 时的 PTX 资源（兜底，通用）
lib/libnvinfer_builder_resource_sm120.so.10.16.1  建 engine 时的原生资源（本机 5060 = sm_120，更快）
lib/libnvonnxparser.so.10.16.1            4.8 MB  trtexec 解析 ONNX 用
lib/libnvinfer_plugin.so.10.16.1         42.5 MB  保险（模型没用到 plugin，先放着）
cudart/usr/local/cuda-13.2/.../{include,lib}      libcudart 13.2.86（dpkg -x 从 deb 解出来的）
```

### 三个当时卡住的点（下次照做）

1. **软链要自己补**。tar 包里 `libnvinfer.so → libnvinfer.so.10 → libnvinfer.so.10.16.1`
   是三条独立记录，只抠 `.so.10.16.1` 的话：链接器找不到 `libnvinfer.so`、
   运行期 dlopen 找不到 `libnvinfer.so.10`。补软链：

   ```bash
   cd ~/TensorRT/lib
   ln -sf libnvinfer.so.10.16.1 libnvinfer.so.10 && ln -sf libnvinfer.so.10 libnvinfer.so
   ln -sf libnvonnxparser.so.10.16.1 libnvonnxparser.so.10
   ln -sf libnvinfer_builder_resource_ptx.so.10.16.1 libnvinfer_builder_resource_ptx.so.10
   ln -sf libnvinfer_builder_resource_sm120.so.10.16.1 libnvinfer_builder_resource_sm120.so.10
   ```
   （`libnvinfer_builder_resource_ptx` 的 SONAME 是个占位符 `do_not_link_against_…`，
   但 TRT 内部是按**文件名**去 dlopen 的，所以名字必须补对。）

2. **CUDA 头文件缺 `crt/`**。`cuda-cudart-dev` 的 deb 里 `host_defines.h` 是平铺的，
   而 `cuda_runtime_api.h` 里写的是 `#include "crt/host_defines.h"` —— 编译时直接
   `fatal error: crt/host_defines.h: 没有那个文件或目录`。**`crt/` 在另一个包**：

   ```bash
   curl -O https://developer.download.nvidia.cn/compute/cuda/repos/ubuntu2404/x86_64/cuda-crt-13-2_13.2.86-1_amd64.deb
   dpkg -x cuda-crt-13-2_13.2.86-1_amd64.deb ~/TensorRT/cudart/       # 版本号要跟 cudart 对上
   ```

3. **CMake 原来写死了"必须有 pip 的 tensorrt 包"**，本机没有，直接 FATAL_ERROR，
   根本走不到 `~/TensorRT` 的兜底路径。已改成：pip 包找到就用，找不到就用 `~/TensorRT*`。

### 建 engine（唯一一条命令）

```bash
cd /home/king/tdt-learning4.5 && bash tools/build_engine.sh
```

脚本内部就是 `trtexec --onnx=... --saveEngine=models/infantry_v8n.engine --fp16`
（带好 `LD_LIBRARY_PATH=~/TensorRT/lib`）。本机实测 **几秒钟就建完**
（有 sm_120 原生资源 + 显式 batch=1），engine 7.9 MB。

> engine 与 GPU 架构 / TensorRT 版本绑定，换机器或升级 TRT 要重跑这一条。
> 本机 GPU = RTX 5060 Laptop（compute capability 12.0 / sm_120）。

## 4. 为什么下了半天：网络实测

本机没有 CUDA toolkit、没有系统 TensorRT、没有 libcudart，全部要现下。实测各条路：

| 源 | 实测速度 | 结论 |
| --- | --- | --- |
| 代理（127.0.0.1:7897）→ pypi.org | 3–9 KB/s | 不可用 |
| 代理 → GitHub release | 85 KB/s | 太慢 |
| 直连 阿里云 PyPI 镜像 | **1.79 MB/s** | 快，**但** 10.13 之后 NVIDIA 把真正的 wheel 挪去了 `pypi.nvidia.com`，阿里云上没有 |
| 直连 `pypi.nvidia.com` | 301 / 代理 5 KB/s | 不可用 |
| **`developer.download.nvidia.cn`（NVIDIA 中国 CDN）** | **2.3–8 MB/s** | ✅ **就用这个** |

NVIDIA 中国 CDN 上 TensorRT 10.16 的完整包（含 `include/`、`lib/`、`bin/trtexec`）就是第 3 节那条链接。
包内顺序对只抠文件有利：`bin/` → `doc/` → `include/` → `lib/`，需要的都在前面。

**踩到的坑：边下边抠的看门狗别扫太勤**。`tar -tzvf` 看一个 7 GB 的 gzip 要整包解压一遍，
每 30 秒扫一次会把下载从 8 MB/s 拖到 1 MB/s。改成"涨了 200 MB 才扫"（`wait3.sh`）
或者干脆下完再抠，速度就回来了。

### 单独说 cudart（TRT 包里不含 CUDA 运行时）

同 CDN 的 CUDA apt 仓库，直连也很快。**注意本机 sudo 需要密码，所以没走 `dpkg -i`，
而是用 `dpkg -x` 免 root 解到本地目录**：

```bash
curl -s https://developer.download.nvidia.cn/compute/cuda/repos/ubuntu2404/x86_64/ \
  | grep -oE 'cuda-cudart(-dev)?-13-2_[^"]*\.deb' | sort -u
# 下最新的那两个（13.2.86），外加 cuda-crt-13-2（见第 3 节第 2 点），然后
mkdir -p ~/TensorRT/cudart && dpkg -x cuda-cudart-13-2_13.2.86-1_amd64.deb ~/TensorRT/cudart/ \
  && dpkg -x cuda-cudart-dev-13-2_13.2.86-1_amd64.deb ~/TensorRT/cudart/ \
  && dpkg -x cuda-crt-13-2_13.2.86-1_amd64.deb ~/TensorRT/cudart/
```

产物在 `~/TensorRT/cudart/usr/local/cuda-13.2/targets/x86_64-linux/{include,lib}`，
`CMakeLists.txt` 的探测逻辑已经认这个路径（也认 pip 的 `nvidia-cuda-runtime-cu13`）。

## 5. 验收清单（已逐条跑过）

- [x] 输入输出形状：engine 的 binding 是 `images 1x3x480x640 fp32` → `output0 1x21x6300 fp32`
- [x] 关键点四角框正：`近距离陀螺.avi` 上四边框紧贴装甲板，**没有蝴蝶结**
      （把模型原始四点用 OpenVINO 单独跑出来叠在标注帧上，与程序画的框逐点重合）
- [x] 兵种名与画面上的数字一致：板上写 "2"，标签是 `two`（工程）
- [x] 大小板判断正确：`近距离陀螺` 里 PnP 解出 2.26 m，与画面里机器人成像高度
      （~510 px ⇒ 0.5 m 的机器人在 2.26 m 处）自洽；若按大板算会变成 4.1 m，明显不符
- [x] 整段 `远距离平移.avi` 跑完：**1546 帧，退出码 0，全程保持锁定，无崩溃 / 无 NaN / EKF 未发散**
      （目标距离 5.4–5.7 m，框稳定跟随）
- [x] 每帧耗时：**2.3–2.4 ms**（TensorRT FP16，5060）。engine 裸推理 trtexec 自己量是 0.59 ms/次
- [x] `grep -ri "openvino\|tiny_resnet" src/ CMakeLists.txt` 只在**注释**里命中（说明改了什么），
      代码与 CMake 里没有残留；`config.yaml` 里也没有 `yolo_model` 之类的死配置

想自己复现：

```bash
cd /home/king/tdt-learning4.5/build && ./auto_aim              # 带窗口，跑 config.yaml 里的视频
# 无窗口批量复核（会把标注帧写出来）：
#   config.yaml 里 show_window: false / save_frames_dir: "/tmp/frames" / save_every_n: 30
./auto_aim /tmp/config_test.yaml 2>&1 | tail -20               # 也可以直接传另一份配置
```

## 6. 已知问题 / 待办

1. **基地顶部/底部都映射成 `base`**：同一个基地的两块板会进同一个 track，EKF 可能被拽偏。
   先这样跑，出问题再把 `base` 拆开。
2. **NMS 阈值硬编码 0.2**（在部署库里，`defaultNmsThreshold()`），`config.yaml` 里的
   `nms_threshold` 已经不起作用。
3. `intr_ready_` 那套"优先用同帧 camera_info"是给 ROS 节点用的；离线跑视频时用 `video:` 块的内参，
   因为自己的录屏是 914×624 / 1888×706 的桌面录屏，内参没有意义，所以离线测试换用了仓库自带的
   1440×1080 真相机视频（内参已与仓库 `camera.json` 核对过，逐位一致）。
4. **ROS 节点已经写好**（见第 8 节），另写了一个精简版，没复用 4.3 的 `contest_node`。
   为什么值得另写：4.3 那版把输出角度的**两个约定都搞错了**（见 8.3），照抄会把云台带偏。

## 7. 备选方案（已不需要，留档）

- **只用 ONNX Runtime CUDA EP**：`onnxruntime-gpu` 的 wheel 在阿里云 PyPI 上有（约 250 MB，1.79 MB/s
  两分钟下完），配套 `nvidia-cuda-runtime-cu12` / `nvidia-cudnn-cu12` 也都在 PyPI。
  功能和速度都够用，但**不是 TensorRT**，与本次要求不符 —— 现在 TensorRT 已经装好，不用退这一步了。
- **换台机器下好再拷**：TensorRT 引擎与 GPU 架构绑定，但**装好的 TensorRT 库本身不绑定** ——
  `~/TensorRT` 整个目录可以直接拷过来用（`.engine` 必须在本机重新生成）。

---

## 8. ROS 节点（2026-09-27 新写）

### 8.1 在哪、怎么跑

| | |
| --- | --- |
| 节点源码 | `contest_node/src/auto_aim_node.cpp`（329 行，比 4.3 那版 714 行精简一半） |
| 工作区 | `tdt_contest_ws/`（`src/` 下两个软链：本包 + `tdt_interface`） |
| 编译 | `cd tdt_contest_ws && ./build.sh` |
| 运行 | `./run.sh` |

数据流：`/autoaim/frame` → 校验/解码 → `Detector`(TensorRT) → `Solver`(PnP) →
`Tracker`(EKF) → `Aimer` → `/target_angles_player_N`(`SendData`)。

四个运行参数（默认**只观察**，一个指令都不发）：

```bash
./run.sh                                                              # 只观察
./run.sh --ros-args -p publish_angles:=true                           # 真的接管云台
./run.sh --ros-args -p publish_angles:=true -p auto_fire:=true        # 附带射击许可
./run.sh --ros-args -p show_window:=true                              # 开窗口看检测
```

规则相关（7.1/7.2/7.5）都实现在节点里：内参优先同帧 `camera_info`（取不到才回落表 12
标称值，并按图像尺寸缩放）；嵌套时间戳不一致 / 帧龄超限 → 丢帧并**主动撤射击许可**；
断流超 0.5 s 看门狗发 `if_shoot=false`；`frame_sequence` 回退 → 按换局清滤波器。

精简取舍：**不发底盘速度**（`/target_speed_player_N` 没动，底盘还是手动）、不录视频、
不做按键交互。

### 8.2 没有游戏怎么验证

`contest_node/tools/publish_test_video.py` 会把仓库测试视频按 `/autoaim/frame` 的格式
（压缩图像 + camera_info + state）真实地发到话题上，所以**不用开游戏就能验整条链路**：

```bash
# 终端 1
cd ~/tdt-learning4.5/tdt_contest_ws && ./run.sh --ros-args -p publish_angles:=true -p auto_fire:=true
# 终端 2
python3 contest_node/tools/publish_test_video.py 近距离陀螺.avi
```

实测（2026-09-27）：节点从 `camera_info` 取到 1440×1080 的内参、每帧回令角度、
断流 0.56 s 自动撤销射击许可、`frame_sequence` 回退时打印"按换局处理"。
输出角度还与像素几何对得上：远距离平移那段板在 x≈220（cx=721）→ 解出 yaw −12.8°
（几何值 −12.4°），y≈215（cy=606）→ pitch −11.8°（几何 9.6° 仰角 + 弹道下坠补偿）。

### 8.3 ★ 4.3 那版把输出角度的约定写反了（另写节点的主要原因）

游戏 `SendData` 的约定是：**yaw 顺时针为正（Unity +Z 为 0）、pitch 向下为正**。
4.3 的 `auto_aim_node.cpp` 两处都反着算：

| 量 | 4.3 的写法 | 正确写法 |
| --- | --- | --- |
| yaw 相对方位角 | `atan2(前, 右)` → 正前方会算成 **+90°** | `atan2(右, 前)` → 正前方为 0 |
| pitch | `+rad2deg(aim.pitch)`（`aim.pitch` 是**仰角**，向上为正） | `-rad2deg(aim.pitch)` |

判据：`aim_3d` 在 pseudo 系，三个分量是 (右, 前, 上)（见 `target.hpp` 顶部），
所以从"前"轴量方位角才是相对光轴的偏角；`Aimer::solve_traj()` 解出的 pitch 是
相对水平面的仰角，而游戏要的是向下为正的世界俯仰角。

（4.4 的节点已按右列实现，并用上面 8.2 的几何对照验过。）

### 8.4 观测搬进世界系（2026-09-27 加）

**问题**：原来整条链路都在云台系里跑，EKF 不知道云台在转。云台一动，目标在它眼里就整体跟着转，
被当成目标的真实运动 —— 最难受的是"指令发出、云台正在转过去"那一段。

**做法**：进 EKF 之前把本帧观测搬到世界系。**只做旋转，原点仍在云台中心**（相机光心）——
所以严格说它是"世界对齐系"而不是世界系：轴不跟着云台转了，原点跟着机器人跑。

| 改动 | 位置 |
| --- | --- |
| `world_from_cam(ψ, θ) = Rz(-ψ)·Rx(-θ)`（pseudo 基，两级换基到相机排版） | `auto_aim_node.cpp` 匿名 namespace |
| 每帧把 `a.xyz_in_camera` 和板法线 `a.yaw` 一起转进世界系 | `armors_to_world()` |
| `Solver::set_frame_rotation(Rᵀ)`：所有"状态→像素"的投影自动转回相机系 | `solver.hpp/.cpp` |
| 输出简化成世界系直读：`world_yaw = atan2(右, 前)`、`world_pitch = -aim.pitch` | `auto_aim_node.cpp` |

板法线角不能只"加个 yaw 偏移"：相机有俯仰时它不再是水平向量，得还原成单位向量 →
旋转 → 再取回角度（`Solver` 那边定义 `a.yaw = atan2(nz, nx)`）。不转的话，观测里
`face_yaw` 和状态里的车朝向不同系，数据关联会错。

输出公式变简单是**必然**的：云台姿态已经烘进观测旋转里，所以不再需要
`+yaw_now`、`-pitch_now` 那两项（8.3 表格右列是"没有世界系"时的写法）。

**验证**（`tools/publish_test_video.py` 支持 `--yaw/--pitch/--yaw-rate` 模拟云台姿态）：

| 用例 | 预期 | 实测 |
| --- | --- | --- |
| ψ=θ=0 | 与改前逐位一致 | yaw −12.5…−12.8°、pitch −11.8° ✅ 完全一致 |
| ψ=30°（云台右转 30°） | 世界 yaw 平移 30° | **+17.43°** = 30 + (−12.56) ✅ |
| θ=20°（云台下俯 20°） | pitch 加 20° 且带 cos 耦合 | **+7.75°** ≈ 11.8 − 20·cos(12.5°) ✅ |

第三个用例顺带证明了 3D 旋转把 **yaw-pitch 耦合**也处理对了：目标在画面里偏 12.5° 时，
俯仰 20° 对它的影响是 `20·cos(12.5°)` 而不是整整 20°——旧的"角度加减"写法会差 0.5°。

**已知局限**：不是严格世界系（原点跟着车跑）。对瞄准来说这正合适 —— EKF 估的就是目标
**相对我们**的运动，提前量拿到的就是该用的量；要绝对世界系得再减 `state.position`，
而那个字段是场景单位（**3 场景单位 = 1 米**）且为 FLU 映射 `(Unity Z, -Unity X, Unity Y)`，
多一次换算就多一个坑，自瞄用不上，没做。

**踩过的坑（记一笔）**：`Tracker::predict_armor()` 的文档说"返回到相机系"，我一度以为它
返回的是状态系，就"顺手修"了 `visualizer.cpp` 里那句 —— 结果 z 变成负数，预测箭头再也画不
出来。临时加调试打印才看清：它在函数末尾**确实**做了 `Target::pseudo_to_camera()`，原来那
句是对的。已撤回。教训：**改之前先看返回值的实际数据，别只看名字/注释。**

### 8.5 开火决策（照同济 sp_vision_25，2026-09-27 加）

参考 `/home/king/下载/sp_vision_25-main/tasks/auto_aim/shooter.cpp`（全文 30 行）：

```cpp
if (!command.control || targets.empty() || !auto_fire_) return false;
double tolerance = horizon_distance > judge_distance ? second_tolerance : first_tolerance;
if (|last_command_.yaw - command.yaw| < tolerance * 2      // ① 指令不突变
 && |gimbal_pos[0]   - last_command_.yaw| < tolerance     // ② 云台已追到上一条指令
 && aimer.debug_aim_point.valid)                          // ③ 瞄准点有效
  { last_command_ = command; return true; }               // 开火
last_command_ = command; return false;
```

三条门槛的含义与几个细节：

| | 判据 | 防的是什么 |
| --- | --- | --- |
| ① 指令不突变 | 本帧指令 vs **上一条指令** yaw 差 < 2×容差 | 刚换目标/瞄准点跳变时立刻开枪打飞 |
| ② 云台到位 | 云台**实际** yaw vs **上一条指令** yaw 差 < 容差 | 指令发出去了、云台还在转的"假到位"（比上一条而非本帧） |
| ③ 解算有效 | 弹道有解、目标可见 | 打不了的目标 |

- **容差按距离分档，远的更严**（standard4.yaml：近 3°、远 2°，阈值 2 m）
- `last_command_` **每帧都更新**（不管开不开火）→ ① 实际是"连续两帧指令一致"
- 没目标时函数最前面就 return，`last_command_` 不更新 → **丢锁再上锁要重新等稳定**
- 它**只看 yaw 不看 pitch** —— 游戏侧还有 1.2° 的伺服到位门兜底

**搬到我们这边**（`auto_aim_node.cpp` 的 `decide_fire()`）：

| sp_vision | 我们 |
| --- | --- |
| `gimbal_pos[0]`（CBoard 读回的实际角） | `state.yaw_degrees`（游戏报的世界光轴角） |
| `last_command_.yaw` | `prev_cmd_yaw_` |
| `horizon_distance` | 锁定目标 EKF 状态的 `sqrt(x(0)²+x(2)²)` |
| `auto_fire`（yaml） | 仍是 ROS 参数 `auto_fire` |

阈值放 `config_contest.yaml`：`first_tolerance: 3.0` / `second_tolerance: 2.0` / `judge_distance: 2.0`。
启动时会把这几个值打进日志。

**注意 SendData 只有三个字段**（yaw / pitch / if_shoot）：没有单独的"开火指令"，
"云台到哪了"也只能靠 `state` 反馈，所以 ② 用的是实际角而不是我们发出去的值。
（前提：`state.yaw_degrees` 是实际光轴角、会随伺服逼近指令 —— 若它其实是回显指令，
条件 ② 会恒真失效，这一点得真游戏接管后确认。）

**测试**（ROS_DOMAIN_ID=42 与游戏隔离，喂帧脚本 `--follow` 模拟 300°/s 云台伺服）：

```
735 条指令里 278 条 if_shoot=是
启动阶段云台在 0°、指令 ~-10° → 全部 否（没到位不打）✅
云台追上后进入 是，指令跳变时退回 否 ✅
```

顺带把"two / four 分类不一致"的疑点彻底钉死了：那次是**游戏在跑**，它的帧和喂帧脚本的
帧混进了同一个话题（85 fps 其实是游戏的帧率）。隔离域下重测，分类稳定是 `two`，与离线
跑视频一致。**游戏开着的时候别用喂帧脚本**。

### 8.6 状态机：搜索 / 确认 / 跟踪 / 暂丢（2026-09-27 加）

需求：没锁定时云台转着找；锁定就打；丢帧容忍 15 帧。

```
            看到目标                 连续 min_detect_count(5) 帧看到 + 已锁定
  搜索 ──────────────► 确认 ─────────────────────────────► 跟踪
   ▲                    │ 连续 3 帧看不到                     │ 丢了
   │                    └──────────────► 搜索 ◄──────────────┤
   └────────── 暂丢超过 max_temp_lost_count(15) 帧 ──────────┘
                                   暂丢（保持不动，等目标回来）
```

| 状态 | 动作 | 说明 |
| --- | --- | --- |
| 搜索 | `yaw += search_yaw_rate(120°/s) × dt`，pitch 回正，**不开火** | 匀速转一圈找目标 |
| 确认 | **保持不动**，不开火 | 停住让跟踪器锁 + 等 EKF 收敛，防单帧误检抢锁 |
| 跟踪 | 正常瞄准 + 开火决策（8.5） | |
| 暂丢 | **保持不动**，不开火 | 目标被遮挡/转走了，15 帧内回来就直接回跟踪（EKF 一直在预测） |

实现要点：

- 状态机跑在**每帧处理**里（`decode_and_aim`），所以它的"时钟"就是帧；**没有帧就不会动**
  （真游戏帧是连续的，没问题；离线测试要记得喂帧）
- 首帧把"上一条指令"对齐到云台**实际角**（`state.yaw_degrees`），免得一上来甩云台
- `dt` 取帧间隔并限幅 0.5 s，防止卡顿后搜索一次转一大截
- "保持不动"= 不更新 yaw/pitch，重发上一条指令（游戏侧 0.5 s 超时会清指令，所以必须重发）
- `max_temp_lost_count` 同时喂给 **Tracker**（解锁阈值）和节点（暂丢容忍），两边一致：
  config 里改一个值即可。默认 15，与 sp_vision 相同
- `min_detect_count = 5` 也是 sp_vision 的值

**测试**（ROS_DOMAIN_ID=42 隔离，喂帧脚本 `--blank` 造空场景）：

```
无帧/空场景 → 状态=搜索，发出的 yaw 每帧 +4°（120°/s @30fps）✅
切入有目标的视频 → 搜索 → 确认 →（约 130 ms，5 帧）→ 跟踪 ✅
切回空场景 → 跟踪 → 暂丢 →（0.42 s ≈ 15 帧）→ 搜索 ✅
```

### 8.7 前哨站专用 EKF（2026-09-27 加，参考 auto_aim_rps26）

前哨站的几何和车完全不同，所以在 `Target` 里开了一条支路（`is_outpost_`），
状态从 11 维换成 **10 维**，仍然放在 `tracks_` 里、走同一套 EKF/关联/可视化：

```
[x, vx, y, vy, z, vz, yaw, v_yaw, dz1, dz2]
                              ^转速   ^^ 1、2 号板相对 0 号板的高度增量
```

| | 车模型（11 维） | 前哨站（10 维） |
| --- | --- | --- |
| 半径 | 状态量 r、还要估 dr | **固定 0.275**（旋转直径 550mm），不估 |
| 高度 | 一块 dh 描述侧板高差 | **dz1 = 0.102、dz2 = 0.204**（1216−1114、1318−1114 mm） |
| 转速 | 自由状态 ω（小陀螺能到几百 °/s） | **只有 ±0.8π**（±144°/s），投票定方向后写死 |
| 板数 | 4（步兵） | 3，绕中心匀布（间隔 2π/3） |
| 发散判据 | r、r+dr ∈ (0.05, 0.5) | \|dz1\|,\|dz2\| < 0.5 且 \|v_yaw\| ≤ 0.8π+1 |
| dz 的过程噪声 | ——（dh 的 Q = 0，当常数） | **q_dz = 5.0**（`dt⁴/4·q_dz`，只加在对角线上；参考工程给 10）。留一条极细的修正通道，免得收敛后协方差缩到 0、滤波器自负 |

**方向投票**（`Target::vote_direction`，照抄 rps26 的 `calDirection` 思路）：
每帧攒一个"观测到的板法线角"，够 30 个样本就逐对比较**间隔 3 个样本**的角度差，
按符号计票（差 > 0.4 rad 的当成换板跳变、不计票）。**不投"静止"那一档** ——
前哨站只有顺/逆时针两种情况，所以只需在 cw/ccw 里取票多者；定了之后
`predict()` 每帧把 `x(7)` 压回 ±0.8π、并把 `P(7,7)` 压到 1e-4。

顺带：原来 `predict()` 里那句"前哨站 ω 超过 2.0 就按符号钳到 ±2.51"的启发式补丁
被删了 —— ±2.51 正好就是 0.8π，现在是用投票＋硬约束正经做的。

**离线仿真自检**（`tests/outpost_sim.cpp`，不依赖相机/游戏）：

```bash
cd /home/king/tdt-learning4.5
g++ -std=c++20 -O2 -Wno-deprecated-enum-enum-conversion -I src tests/outpost_sim.cpp \
    src/target.cpp $(pkg-config --cflags --libs opencv4) -I /usr/include/eigen3 -o /tmp/outpost_sim
/tmp/outpost_sim      # 逆时针
/tmp/outpost_sim -    # 顺时针（参数带负号）
```

造一个真值前哨站（半径 0.275、转速 ±0.8π、三块板不同高），按"最正对相机的那块板"
逐帧生成带噪声的观测（2 mrad / 2 cm），喂 300 帧（100 Hz），实测两个方向都：

```
位置误差 0.055 m | dz1/dz2 = 0.103/0.205（真值 0.102/0.204）
投票方向正确（顺/逆各测一次）| v_yaw 收敛到 ±2.513 = ±0.8π（差 8e-6）| 发散 0 帧
```

真机上还没验证（要游戏里按 F8 开 ROS、且前哨站出现在视野里才能看到）。

### 8.8 基地：照常锁定，但瞄准不用 EKF/预测（2026-09-27 加）

基地还是**普通目标**：照常进 `Tracker`、照常被锁定、框和锁定圈照画、
最佳击打点照画 —— **只有"瞄准怎么算"这一步不一样**：

| | 车 | 基地 |
| --- | --- | --- |
| 锁定 / 画框 / 锁定圈 | ✅ | ✅ 一样 |
| 瞄准点怎么算 | EKF 预测 + 提前量（`Aimer::best_aim`） | **直接用这一帧观测到的板中心**（`Aimer::best_aim_direct`），不预测 |
| 重力补偿 | ✅ | ✅ 一样（`aim_3d = 板中心 + ½g t²`） |
| 开火判据 | `decide_fire` 三条 | ✅ 一样 |

理由：基地是**静止结构**，提前量没有意义；而它的 EKF 又容易被两块板（上下都映射成
`base`）拽到发散——**发散后 `!diverged()` 会把开火挡死**，这正是之前"锁着却一枪不放"
的原因。现在瞄准不经过 EKF，发散也不影响开火。

实现要点：

- 判定条件是"**锁定的目标是 base**"（`tracker_->locked_id() == (int)base`），
  所以锁定/状态机/优先级全都不用改
- `decode_and_aim` 里在这一支走 `Aimer::best_aim_direct(p_state, solver)`
- ★ **换系别漏**：`Armor::xyz_in_camera` 是**相机排版**(右/下/前)，而
  `best_aim_direct` 要的是**状态系**(右/前/上)，差一次轴重排 `pseudo = (x, z, -y)`。
  第一版就是漏了这步 —— 把"前"当成"上"（十几米），弹道解出一支近乎垂直上抛的解
  （pitch ≈ 79°），准星也因此投射到错误位置（表现为"黄准星落在板中心下方"）。
  测试里加了往返换系断言，把这条约定钉住。
- 上下两块板同时可见时，取**离画面中心最近**的那块（`pick_base_plate`）
- 画图和锁定圈不受影响：`Visualizer` 用的是 tracker 的 `locked_id` 和检测框，
  瞄准点用的是 `aim.aim_2d`（这条分支也会填）
- **不画"预测点"箭头**：那条箭头是 EKF 预测出来的，基地压根不用 EKF，
  画出来只是跟踪器的猜测、跟实际瞄点不一致。`Visualizer::draw()` 加了
  `draw_prediction` 参数（默认 true），节点在直瞄基地时传 false，只留黄准星

**自检**（`tests/base_direct_test.cpp`，弹道有解析解可以直接对）：

```bash
cd /home/king/tdt-learning4.5
g++ -std=c++20 -O2 -Wno-deprecated-enum-enum-conversion -I src tests/base_direct_test.cpp \
    src/aimer.cpp src/solver.cpp src/target.cpp $(pkg-config --cflags --libs opencv4) \
    -I /usr/include/eigen3 -o /tmp/base_direct_test && /tmp/base_direct_test
```

```
v0=25, d=5m, h=-1m:
pitch  = -9.0828°  (手算 -9.0828°)   ✅
flight =  0.2025 s (手算  0.2025 s)  ✅
aim_3d = (0, 5, -0.799) = 板中心 -1 + 下坠 0.201  ✅
```

### 8.9 PnP 二义性：yaw 暴力优化（2026-09-27 加）

**问题**：一块平板（4 个共面角点）的 PnP 天生有两支解（"正面朝我"／"背面朝我"），
`cv::solvePnP(IPPE)` 挑哪支不保证。**前哨站上这个错误很致命**：板法线反 180° →
观测到的板方位角往反方向转 → 8.7 节那个方向投票和 EKF 的顺/逆时针**整个反掉**。

参考 `sp_vision_25-main/tasks/auto_aim/solver.cpp` 的 `Solver::optimize_yaw`：
位置固定、只扫 yaw、用重投影误差挑，并且**靠"板基本朝着我们"这条先验限制搜索范围**。

我们的实现（`Solver::optimize_yaw`）：

- **候选姿态由 yaw 直接重建**（假设装甲板竖直：法线水平、板高方向竖直），
  而不是把 PnP 的解转一转 —— 见下面的坑
- 重建在世界系里做（用已有的 `cam_from_world_`），所以 ROS 节点（云台会俯仰）
  和离线跑视频（单位阵）用的是同一套代码
- 判据：**法线必须背离相机**（`n·p > 0`）—— 装甲板只有正面能被看到，
  而模型里板的法线指向"板 → 车中心"，看正面时它必然指向场景深处
- 搜索：整圈粗扫 5° → ±4° 细扫 1° → ±1° 再细扫 0.25°
- 代价：每帧约 +0.5 ms（6 块板 × ~90 个候选，手工投影不用 `cv::projectPoints`）

**踩过的坑**：第一版把候选写成"绕竖直轴旋转 PnP 的那个解"。这**到不了真值** ——
镜像那支和真值之间差的是**反射**、不是旋转，于是所有候选都被 `n·p>0` 淘汰，
函数提前返回、退回原来那支错解。合成测试里表现为"全角度都失败、且解出的 `n·p` 还是负的"。

**自检**（`tests/solver_yaw_test.cpp`，合成真值位姿 + 0.7px 像素噪声）：

```bash
cd /home/king/tdt-learning4.5
g++ -std=c++20 -O2 -Wno-deprecated-enum-enum-conversion -I src tests/solver_yaw_test.cpp \
    src/solver.cpp src/target.cpp $(pkg-config --cflags --libs opencv4) -I /usr/include/eigen3 \
    -o /tmp/solver_yaw_test && /tmp/solver_yaw_test
```

```
真值 yaw=  -5.0° | 原始 IPPE=+164.3° ← 取错支! | 优化后=  -6.8° ✅
真值 yaw= +25.0° | 原始 IPPE= +27.6°            | 优化后= +27.8° ✅
真值 yaw= +55.0° | 原始 IPPE=+102.8° ← 取错支! | 优化后= +51.5° ✅
真值 yaw= +90.0° | 原始 IPPE= +97.7° ← 取错支! | 优化后= +97.5° ✅
真值 yaw=+130.0° | 原始 IPPE=+123.6° ← 取错支! | 优化后=+123.3° ✅
== 全部通过 ==   （6 个角度里原始 IPPE 取错 4 个，优化后 0 个）
```

残余误差 1.7–7.5°，来自"小装甲板在 5m 处只有 ~31px 宽 + 像素噪声"：
斜视时 yaw 本身病态。**对前哨站够用**（投票只看旋转方向的符号，EKF 还会自己滤），
不追求更高精度。
